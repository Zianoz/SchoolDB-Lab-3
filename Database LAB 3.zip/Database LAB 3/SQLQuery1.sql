CREATE DATABASE SchoolDB
GO

USE SchoolDB
GO

-- Table for employees with distinct roles
CREATE TABLE Employees(
    EmployeeID INT IDENTITY (1,1) PRIMARY KEY,
    EmployeeRole NVARCHAR(20) NOT NULL,
    EmployeeFirstName NVARCHAR(20) NOT NULL,
    EmployeeLastName NVARCHAR(20) NOT NULL
);
GO

-- Table for students
CREATE TABLE Students(
    StudentID INT IDENTITY (1,1) PRIMARY KEY,
    StudentFirstName NVARCHAR(20) NOT NULL,
    StudentLastName NVARCHAR(20) NOT NULL,
    StudentPersonNumber NVARCHAR(20) NOT NULL UNIQUE,
    ClassID INT NOT NULL -- Foreign key to Classes table
);
GO

-- Table for classes
CREATE TABLE Classes(
    ClassID INT IDENTITY (1,1) PRIMARY KEY,
    ClassName NVARCHAR(30) NOT NULL --
);
GO

-- Table for grades assigned to students for specific courses
CREATE TABLE Grades(
    GradeID INT IDENTITY (1,1) PRIMARY KEY,
    StudentID INT NOT NULL, -- Foreign key to Students table
    EmployeeID INT NOT NULL, -- Foreign key to Employees table (teacher who assigned the grade)
    Grade NVARCHAR(2) NOT NULL,
    AssignedDate DATE NOT NULL,
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
    FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID)
);
GO

-- Adding foreign key constraints
ALTER TABLE Students
ADD CONSTRAINT FK_Students_Classes FOREIGN KEY (ClassID) REFERENCES Classes(ClassID);
GO

-- Insert test data into Employees table
INSERT INTO Employees (EmployeeRole, EmployeeFirstName, EmployeeLastName) VALUES
('Teacher', 'Anna', 'Andersson'),
('Teacher', 'Bertil', 'Berg'),
('Administrator', 'Cecilia', 'Carlsson'),
('Principal', 'David', 'Dahl');
GO

-- Insert test data into Classes table
INSERT INTO Classes (ClassName) VALUES
('Class A'),
('Class B');
GO

-- Insert test data into Students table
INSERT INTO Students (StudentFirstName, StudentLastName, StudentPersonNumber, ClassID) VALUES
('Eva', 'Eriksson', '19990101-1234', 1),
('Fredrik', 'Fors', '20000101-2345', 1),
('Greta', 'Gustafsson', '20010101-3456', 2);
GO

-- Insert test data into Grades table
INSERT INTO Grades (StudentID, EmployeeID, Grade, AssignedDate) VALUES
(1, 1, 'A', GETDATE()),
(2, 2, 'B', DATEADD(DAY, -10, GETDATE())),
(3, 1, 'C', DATEADD(DAY, -40, GETDATE()));
GO

-- Query to fetch all teachers
SELECT * FROM Employees
WHERE EmployeeRole = 'Teacher';
GO

-- Query to fetch all students in alphabetical order by last name
SELECT * FROM Students
ORDER BY StudentLastName;
GO

-- Query to fetch all students in a specific class
SELECT s.* FROM Students s
JOIN Classes c ON s.ClassID = c.ClassID
WHERE c.ClassName = 'Grade 10A';
GO

-- Query to fetch all grades assigned in the last month
SELECT g.* FROM Grades g
WHERE AssignedDate >= DATEADD(MONTH, -1, GETDATE());
GO
